# symbols.py - Nifty 500 and F&O stocks
stock_list = [
    "RELIANCE", "INFY", "TCS", "HDFCBANK", "ICICIBANK", "SBIN",
    "ITC", "LT", "AXISBANK", "MARUTI", "BAJFINANCE", "SUNPHARMA"
]
